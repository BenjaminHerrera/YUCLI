import os

os.environ["KIVY_NO_CONSOLELOG"] = "1"

from yucli import console