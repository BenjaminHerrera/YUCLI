from yucli import console

a = console.Console(800, 600)

a.run()